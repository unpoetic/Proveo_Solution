
import './App.css';
import EmployeeInfoCard
 from './components/EmployeeInfoCard';
function App() {
  return (
    <div className="App">
      <header className="App-header">

		<EmployeeInfoCard></EmployeeInfoCard>
        
      </header>
    </div>
  );
}

export default App;
